--drop type Sportiv;
create or replace type Sportiv under Persoana
(
   sport varchar(20),
   persBest int
);
/


