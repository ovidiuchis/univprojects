--drop type Clasament;
create or replace type Clasament as object
(
   loc1 Sportiv,
   loc2 Sportiv,
   loc3 Sportiv
);
/


