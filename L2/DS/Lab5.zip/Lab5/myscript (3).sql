--drop type Sport;
create or replace type Sport as object
(
   nume varchar2(20),
   cclasament Clasament
);
/


