create or replace type sportivi as table of Sportiv;
/
create or replace type sporturi as varray(10) of Sport;
/


