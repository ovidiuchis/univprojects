create or replace type Papusa as object
(
    denumire varchar(10),
    culoare varchar(10)
);
/



