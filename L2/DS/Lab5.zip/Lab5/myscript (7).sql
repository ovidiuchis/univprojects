create table Premii
(
   sportivX ref Sportiv,
   premiu Papusa
);




